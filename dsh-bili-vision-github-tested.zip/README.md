# B站画面：给 Agent 和刷 B 站子代理看视频

独立的 DeepSeek Harness 插件，不修改 `dsh-bili-subagent` 安装包。提供工具 `bili_video_frames`：输入 BV 号，可选 `part`、`start`、`seconds`、`frames`；通过 B站公开 API 获取可播放的视频流，FFmpeg 抽帧，Pillow 每 16 帧生成一张带时间码的 JPEG 拼图，并以图像附件直接返回调用它的 Agent／子代理。

## 安装和依赖

- DSH 插件市场收录后可由市场安装；也可用 DSH 内置插件管理器从本仓库安装。安装包通过 `cordis.patch.yml` 注册服务端插件，并通过 `client.js` 注册「设置 → B站画面」入口。
- Python 需安装 Pillow（`python -m pip install Pillow`），FFmpeg 需在 PATH 中或在设置里指定绝对路径。默认优先尝试 DSH 自带的 Python；如果其环境未安装 Pillow，请在设置里选择已安装 Pillow 的 Python。
- 「设置 → B站画面」提供总开关、默认/最大取帧数（默认 24 / 96）、处理超时、Python 路径和 FFmpeg 路径。配置保存在 `$DSH_HOME/bili-vision-local/config.json`，更改立即生效。

## 使用

调用 `bili_video_frames({"bvid":"BV12jxj6dEjC", "frames":8})` 先快速预览，再使用 `start`、`seconds`、`frames` 聚焦重要时段。公开接口不能访问、需登录、地区受限或版权限制的视频会明确报错；没有真的拿到画面时绝不应编造视觉信息。评论只能作为待核验线索，视觉不能代替音频/字幕。

本机已在原刷 B 站插件的**用户配置** `scanPrompt`、`watchPrompt` 里启用调用指引；这些是用户配置而非上游源码，其他用户需自行在原插件设置中加入「推荐前调用 `bili_video_frames` 实际看画面」提示。原插件升级若重置配置，需要再设置。图片存于 `$DSH_HOME/bili-vision-local/<UUID>`，不自动清理。每帧独立 FFmpeg 请求，长视频选 24–96 帧可能较慢。
