import test from 'node:test'
import assert from 'node:assert/strict'
import { defaults, normalize } from './config.js'

test('configuration defaults and frame ceiling stay consistent', () => {
  assert.deepEqual(normalize(), defaults)
  assert.equal(normalize({ maxFrames: 8 }).defaultFrames, 8)
  assert.equal(normalize({ defaultFrames: 200, maxFrames: 96 }).defaultFrames, 96)
})

test('configuration ignores unknown keys and invalid numbers', () => {
  const v = normalize({ enabled: false, timeoutSeconds: -8, defaultFrames: 'no', unwanted: 'secret' })
  assert.equal(v.enabled, false)
  assert.equal(v.timeoutSeconds, 30)
  assert.equal(v.defaultFrames, defaults.defaultFrames)
  assert.equal(Object.hasOwn(v, 'unwanted'), false)
})
