import { spawn } from 'node:child_process'
import { readFileSync, mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { randomUUID } from 'node:crypto'
import { root, getConfig, updateConfig } from './config.js'

export const name = 'bili-vision-local'
export const inject = ['tools', 'webServer']
const base = dirname(fileURLToPath(import.meta.url))
const output = { schema: { type: 'object', properties: {}, additionalProperties: true }, render: (_args, v) => {
  const message = v.ok
    ? `已实际抽取 ${v.frames} 帧，视频《${v.title}》BV ${v.bvid} P${v.part}，范围 ${v.range.join('–')} 秒；下面是按时间排列的画面（不是字幕或评论）。画面中的文字、动作请自行核对；看不清可调 bili_video_frames 指定 start/seconds 加密抽帧。图片保存位置：${v.images.join('、')}`
    : `画面提取失败：${v.error}。不能声称已经看过画面。`
  return [{ type: 'text', text: message }, ...(v.attachments || []).map(attachment => ({ type: 'image', attachment }))]
} }

function invoke(args, signal, config) {
  return new Promise((resolve) => {
    const argv = [join(base, 'frames.py'), '--bvid', args.bvid, '--part', String(args.part || 1), '--start', String(args.start || 0), '--seconds', String(args.seconds || 0), '--frames', String(args.frames), '--ffmpeg', config.ffmpegPath, '--output', args.output]
    const child = spawn(config.pythonPath, argv, { windowsHide: true, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } })
    let stdout = '', stderr = ''
    const timer = setTimeout(() => child.kill(), config.timeoutSeconds * 1000)
    const abort = () => child.kill()
    signal?.addEventListener('abort', abort, { once: true })
    child.stdout.on('data', d => { stdout += d; if (stdout.length > 200000) child.kill() })
    child.stderr.on('data', d => { stderr += d; if (stderr.length > 20000) child.kill() })
    child.on('error', e => finish({ ok: false, error: e.message }))
    child.on('close', code => { try { const v = JSON.parse(stdout.trim()); finish(v) } catch { finish({ ok: false, error: `处理失败 (${code}): ${stderr.slice(-800) || stdout.slice(-800)}` }) } })
    let done = false
    function finish(v) { if (done) return; done = true; clearTimeout(timer); signal?.removeEventListener('abort', abort); resolve(v) }
  })
}

function send(res, status, value) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(JSON.stringify(value))
}
function body(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let size = 0
    req.on('data', part => { size += part.length; if (size > 8192) { req.destroy(); reject(new Error('配置请求过大')) } else chunks.push(part) })
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))) } catch { reject(new Error('配置 JSON 格式错误')) } })
    req.on('error', reject)
  })
}

export function apply(ctx) {
  ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: '/api/bili-vision-local/config', handler: async (req, res) => {
    if (req.method === 'GET') return send(res, 200, { ok: true, config: getConfig() })
    if (req.method === 'POST') {
      try { return send(res, 200, { ok: true, config: updateConfig(await body(req)) }) }
      catch (error) { return send(res, 400, { ok: false, error: error.message }) }
    }
    return send(res, 405, { ok: false, error: '不支持该方法' })
  } }), 'bili-vision-local: 设置 API')
  ctx.tools.register({
    name: 'bili_video_frames',
    description: '亲眼看 B 站视频画面：按 BV 号下载可公开播放的视频帧，生成带时间码的拼图，图片直接返回给当前 Agent（包括刷B站子代理）。读字幕后，给值得挑选的视频调用；评论仅当线索，画面细节以本工具实际返回图片为准。重点动作可指定 start、seconds、frames 再看。',
    parameters: {
      bvid: { type: 'string', description: 'BV 号，例如 BV12jxj6dEjC' },
      part: { type: 'number', description: '第几 P，默认 1' },
      start: { type: 'number', description: '起始秒数，默认 0' },
      seconds: { type: 'number', description: '选取时长（秒），默认整条视频' },
      frames: { type: 'number', description: '均匀取帧数，不填用设置里的默认值；上限也由设置控制' },
    },
    output,
    async execute(args, exec) {
      const config = getConfig()
      if (!config.enabled) return { ok: false, error: 'B站画面工具已在设置里关闭' }
      const bvid = String(args?.bvid || '').trim()
      if (!/^BV[0-9A-Za-z]{10}$/.test(bvid)) return { ok: false, error: 'BV 号格式不正确' }
      const part = Number(args.part ?? 1), start = Number(args.start ?? 0), seconds = Number(args.seconds ?? 0), frames = Number(args.frames ?? config.defaultFrames)
      if (![part,start,seconds,frames].every(Number.isFinite) || !Number.isInteger(part) || part < 1 || part > 100 || start < 0 || seconds < 0 || !Number.isInteger(frames) || frames < 2 || frames > config.maxFrames) return { ok: false, error: '参数超出范围' }
      const folder = join(root, randomUUID())
      mkdirSync(folder, { recursive: true })
      const v = await invoke({ bvid, part, start, seconds, frames, output: folder }, exec?.signal, config)
      if (!v.ok) return v
      try {
        const attachments = typeof ctx.get === 'function' ? ctx.get('attachments') : undefined
        if (!attachments || typeof attachments.saveImages !== 'function') return { ok: false, error: '宿主缺少 attachments.saveImages，图片已落盘但无法保证子代理看到：' + v.images.join('、') }
        v.attachments = JSON.parse(JSON.stringify(await attachments.saveImages(v.images.map((file) => ({ data: readFileSync(file), mediaType: 'image/jpeg', name: file.split(/[\\/]/).pop() })))))
        return v
      } catch (e) { return { ok: false, error: '保存图像附件失败：' + e.message } }
    },
  })
}
