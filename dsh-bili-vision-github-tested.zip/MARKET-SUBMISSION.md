# 提交插件市场

仓库：[yilingyilingyilingyi/B-deepseek-](https://github.com/yilingyilingyilingyi/B-deepseek-)。目录要求见 [贡献指南](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/blob/main/contributing.md)。仓库公开、创建满 1 天且添加 GitHub topic `dsh-plugin` 后可提交市场 PR。仓库创建时间是 2026-11-14 16:48:25（北京时间），最早 2026-11-15 16:48:25 才满足一天门槛。

1. 将本目录的 `package.json`、`cordis.patch.yml`、`index.js`、`config.js`、`client.js`、`frames.py`、`README.md`、`LICENSE` 上传到上述仓库**根目录**。不要上传 `sample/` 或本机生成的配置。
2. fork [目录仓库](https://github.com/awesome-dsh-plugin/awesome-dsh-plugin)，仅新增文件 `data/plugins/yilingyilingyilingyi__B-deepseek-.yml`，内容：

```yaml
url: https://github.com/yilingyilingyilingyi/B-deepseek-
name: yilingyilingyilingyi/B-deepseek-
category: vision
description:
  en: Extracts timestamped Bilibili video contact sheets and returns image attachments to DSH agents, with configurable settings.
  zh: 抽取带时间码的 B 站视频拼图，以图像附件返回给 DSH Agent，并提供可调参数与总开关。
```

3. 向目录仓库提交 PR，等 CI 与维护者审核。收录不等于立即上线；合并后市场按目录同步节奏显示。
