import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'

export const root = join(process.env.DSH_HOME || join(homedir(), '.dsh'), 'bili-vision-local')
const path = join(root, 'config.json')
const bundledPython = join(homedir(), '.dsh', 'dsh-runtimes', 'dsh-next-primary-runtime', 'dependencies', 'python', process.platform === 'win32' ? 'python.exe' : 'bin/python3')
export const defaults = Object.freeze({ enabled: true, defaultFrames: 24, maxFrames: 96, timeoutSeconds: 300, pythonPath: existsSync(bundledPython) ? bundledPython : 'python3', ffmpegPath: 'ffmpeg' })
let current

export function normalize(input = {}) {
  const obj = input && typeof input === 'object' && !Array.isArray(input) ? input : {}
  const int = (key, low, high) => { const n = Number(obj[key]); return Number.isInteger(n) ? Math.max(low, Math.min(high, n)) : defaults[key] }
  const maxFrames = int('maxFrames', 2, 96)
  return {
    enabled: typeof obj.enabled === 'boolean' ? obj.enabled : defaults.enabled,
    defaultFrames: Math.min(int('defaultFrames', 2, 96), maxFrames), maxFrames,
    timeoutSeconds: int('timeoutSeconds', 30, 900),
    pythonPath: typeof obj.pythonPath === 'string' && obj.pythonPath.trim() ? obj.pythonPath.trim().slice(0, 1024) : defaults.pythonPath,
    ffmpegPath: typeof obj.ffmpegPath === 'string' && obj.ffmpegPath.trim() ? obj.ffmpegPath.trim().slice(0, 1024) : defaults.ffmpegPath,
  }
}
export function getConfig() {
  if (!current) {
    try { current = normalize(JSON.parse(readFileSync(path, 'utf8'))) } catch { current = normalize() }
  }
  return { ...current }
}
export function updateConfig(patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('配置必须是对象')
  const keys = Object.keys(defaults)
  const clean = Object.fromEntries(Object.entries(patch).filter(([key]) => keys.includes(key)))
  const next = normalize({ ...getConfig(), ...clean })
  mkdirSync(root, { recursive: true })
  const temp = path + '.' + process.pid + '.tmp'
  writeFileSync(temp, JSON.stringify(next, null, 2), 'utf8')
  renameSync(temp, path)
  current = next
  return getConfig()
}
