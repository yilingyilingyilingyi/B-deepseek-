"""Download a public Bilibili video and produce timestamped contact sheets.
No cookies are read; unavailable/paid/region-blocked videos fail explicitly.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
from PIL import Image, ImageDraw, ImageFont

HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36', 'Referer': 'https://www.bilibili.com/'}

def api(endpoint, params):
    url = 'https://api.bilibili.com' + endpoint + '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=25) as response:
        obj = json.load(response)
    if obj.get('code') != 0:
        raise RuntimeError(f"B站接口拒绝：{obj.get('message')} (code {obj.get('code')})")
    return obj['data']

def clock(s):
    s = int(s)
    return f'{s//3600:02d}:{s//60%60:02d}:{s%60:02d}'

def font(size):
    for name in ('C:/Windows/Fonts/msyh.ttc', 'C:/Windows/Fonts/arial.ttf'):
        if Path(name).exists():
            return ImageFont.truetype(name, size)
    return ImageFont.load_default()

def run(cmd, timeout):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if p.returncode:
        raise RuntimeError((p.stderr or b'ffmpeg failed').decode('utf-8', errors='replace')[-1100:])
    return p.stdout

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bvid', required=True)
    parser.add_argument('--part', type=int, default=1)
    parser.add_argument('--start', type=float, default=0)
    parser.add_argument('--seconds', type=float, default=0)
    parser.add_argument('--frames', type=int, default=48)
    parser.add_argument('--output', required=True)
    parser.add_argument('--ffmpeg', default='ffmpeg')
    args = parser.parse_args()
    if not __import__('re').fullmatch(r'BV[0-9A-Za-z]{10}', args.bvid):
        raise ValueError('BV 号格式不正确')
    if args.part < 1 or args.part > 100 or args.start < 0 or args.seconds < 0 or args.frames < 2 or args.frames > 96:
        raise ValueError('part/start/seconds/frames 参数超出范围')
    meta = api('/x/web-interface/view', {'bvid': args.bvid})
    pages = meta.get('pages') or []
    if args.part > len(pages):
        raise ValueError('分 P 不存在')
    page = pages[args.part-1]
    duration = float(page.get('duration') or meta.get('duration') or 0)
    start = args.start
    end = min(duration, start + args.seconds) if args.seconds else duration
    if end - start < 0.1:
        raise ValueError('所选时间段超出视频长度')
    play = api('/x/player/playurl', {'bvid': args.bvid, 'cid': page['cid'], 'qn': 64, 'fnval': 0, 'fourk': 0})
    streams = play.get('durl') or []
    if not streams or not streams[0].get('url'):
        raise RuntimeError('没有可访问的视频流（可能需要登录、地区受限或版权限制）')
    stream = streams[0]['url']
    count = args.frames
    # An individual extraction seeks precisely; no full-video download or large persistent media files.
    times = [start + (end - start) * i / count for i in range(count)]
    target = Path(args.output)
    target.mkdir(parents=True, exist_ok=True)
    files = []
    card_w, card_h = 360, 232
    columns, rows = 4, 4
    label_font = font(16)
    with tempfile.TemporaryDirectory(prefix='bili-vision-') as temp:
        for n, t in enumerate(times):
            dest = Path(temp) / f'{n:03d}.jpg'
            run([args.ffmpeg, '-hide_banner', '-loglevel', 'error', '-y', '-ss', f'{t:.3f}', '-headers', 'Referer: https://www.bilibili.com/\r\nUser-Agent: '+HEADERS['User-Agent']+'\r\n', '-i', stream, '-frames:v', '1', '-vf', 'scale=352:198:force_original_aspect_ratio=decrease', '-q:v', '5', str(dest)], 45)
            if not dest.exists():
                raise RuntimeError(f'{clock(t)} 没有可解码画面')
            if n % 16 == 0:
                sheet = Image.new('RGB', (card_w*columns, card_h*rows), '#111827')
                draw = ImageDraw.Draw(sheet)
            with Image.open(dest) as frame:
                x, y = (n % columns)*card_w, ((n % 16)//columns)*card_h
                frame.thumbnail((352, 198))
                sheet.paste(frame, (x+(card_w-frame.width)//2, y+3))
                draw.text((x+8, y+202), f'{clock(t)}  ·  {n+1:02d}', fill='#ffffff', font=label_font)
            if n % 16 == 15 or n == count-1:
                path = target / f'{args.bvid}-P{args.part}-{int(start)}-{(n//16)+1:02d}.jpg'
                sheet.save(path, quality=83, optimize=True)
                files.append(str(path))
                sheet.close()
    print(json.dumps({'ok': True, 'bvid': args.bvid, 'title': meta.get('title',''), 'part': args.part, 'duration': duration, 'range': [start,end], 'frames': len(times), 'images': files}, ensure_ascii=False))

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(json.dumps({'ok': False, 'error': str(e)}, ensure_ascii=False))
        sys.exit(1)
