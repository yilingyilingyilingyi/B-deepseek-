window.__ModuleLoader__.load({
  id: 'dsh-bili-vision-local',
  factory: function (require) {
    var React = require('react')
    var h = React.createElement
    var useState = React.useState
    var useEffect = React.useEffect
    var ENDPOINT = '/api/bili-vision-local/config'
    var fields = [
      ['defaultFrames', '默认取帧数', '不指定 frames 时每条视频均匀抽取的帧数（2–96）'],
      ['maxFrames', '最大取帧数', '单次工具调用的帧数上限（2–96）'],
      ['timeoutSeconds', '处理超时（秒）', '超过此时限终止抽帧（30–900）'],
      ['pythonPath', 'Python 路径', '需安装 Pillow；留空会恢复默认值'],
      ['ffmpegPath', 'FFmpeg 路径', '可填 ffmpeg 或可执行文件绝对路径'],
    ]
    function request(method, value) {
      return fetch(ENDPOINT, method === 'GET' ? { cache: 'no-store' } : {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(value),
      }).then(function (response) { return response.json().then(function (data) { if (!response.ok || !data.ok) throw new Error(data.error || '保存失败'); return data.config }) })
    }
    function Panel() {
      var pair = useState(null), cfg = pair[0], setCfg = pair[1]
      var state = useState(''), message = state[0], setMessage = state[1]
      var busy = useState(false), saving = busy[0], setSaving = busy[1]
      useEffect(function () { var active = true; request('GET').then(function (v) { if (active) setCfg(v) }).catch(function (e) { if (active) setMessage(e.message) }); return function () { active = false } }, [])
      function save(patch) {
        setSaving(true); setMessage('')
        request('POST', patch).then(function (v) { setCfg(v); setMessage('已保存，立即生效') }).catch(function (e) { setMessage(e.message) }).finally(function () { setSaving(false) })
      }
      if (!cfg) return h('div', { style: { padding: 24 } }, message || '正在加载 B站画面设置…')
      return h('section', { style: { maxWidth: 720, padding: '18px 24px', lineHeight: 1.65 } },
        h('h2', null, 'B站画面'),
        h('p', null, '独立于刷B站插件：给 Agent 和子代理返回带时间码的视频拼图。只读取可公开播放的视频，不动原插件代码与账号。'),
        h('label', { style: { display: 'flex', gap: 12, alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #8884' } },
          h('span', { style: { flex: 1, fontWeight: 600 } }, '总开关'),
          h('input', { type: 'checkbox', checked: cfg.enabled, disabled: saving, onChange: function (e) { save({ enabled: e.target.checked }) }, 'aria-label': 'B站画面总开关' })),
        fields.map(function (field) {
          var key = field[0], isNumber = typeof cfg[key] === 'number'
          return h('label', { key: key, style: { display: 'flex', gap: 15, alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #8884' } },
            h('span', { style: { flex: 1 } }, h('strong', null, field[1]), h('small', { style: { display: 'block', opacity: .7 } }, field[2])),
            h('input', { key: key + ':' + String(cfg[key]), type: isNumber ? 'number' : 'text', defaultValue: cfg[key], min: isNumber ? (key === 'timeoutSeconds' ? 30 : 2) : undefined, max: isNumber ? (key === 'timeoutSeconds' ? 900 : 96) : undefined,
              style: { width: isNumber ? 100 : 290, maxWidth: '48%', padding: 7 }, disabled: saving,
              onBlur: function (e) { var val = isNumber ? Number(e.target.value) : e.target.value.trim(); if (val !== cfg[key] && val !== '') save({ [key]: val }) },
              onKeyDown: function (e) { if (e.key === 'Enter') e.target.blur() } }))
        }),
        h('p', { role: 'status' }, message),
        h('small', { style: { opacity: .7 } }, '关闭总开关后工具不再抽帧；已保存的图片不会自动删除。需要能运行 Python + Pillow 和 FFmpeg。'))
    }
    return { name: 'bili-vision-local-client', inject: ['slots'], apply: function (ctx) {
      ctx.slots.inject('settings.section', function () {
        return ctx.slots.register({ name: 'settings.section', id: 'bili-vision-local', order: 48, label: function () { return 'B站画面' } }, function () { return h(Panel) })
      })
    } }
  },
})
